﻿namespace lib_dominio.Entidades
{
    public class Productos
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public int Tipo { get; set; }
        public DateTime Fecha { get; set; }
    }
}