﻿namespace lib_dominio.Entidades
{
    public class Tipos
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public DateTime Fecha { get; set; }
    }
}
