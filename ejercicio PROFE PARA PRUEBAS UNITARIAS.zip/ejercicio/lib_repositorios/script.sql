CREATE DATABASE db_ejercicio;
GO
USE db_ejercicio;
GO

CREATE TABLE [tbl_tipos] (
	[id_tipo] INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[nombre_tipo] NVARCHAR(10) NOT NULL,
	[fecha_tipo] SMALLDATETIME NOT NULL,
);

CREATE TABLE [tbl_productos] (
	[id_producto] INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
	[nombre_producto] NVARCHAR(10) NOT NULL,
	[fecha_productos] SMALLDATETIME NOT NULL,
	[tipo] INT NOT NULL REFERENCES [tipos](id),
	[valor_producto] DECIMAL(10,2) NOT NULL,
	[activo_producto] BIT NOT NULL,
);

INSERT INTO [tbl_tipos] ([nombre],[fecha])
VALUES ('Admin', GETDATE());

SELECT * FROM [tbl_tipos];
SELECT * FROM [tbl_productos];