﻿using lib_dominio.Entidades;

namespace ut_presentacion.Nucleo
{
    public class EntidadesNucleo
    {
        public static Tipos? Tipos()
        {
            var entidad = new Tipos();
            entidad.Nombre = "Pruebas-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            entidad.Fecha = DateTime.Now;

            return entidad;
        }
    }
}
