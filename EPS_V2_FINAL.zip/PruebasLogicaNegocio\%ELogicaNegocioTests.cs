   using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PruebasLogicaNegocio
{
    [TestClass]
    public class NombreDeLaEntidadTests
    {
        [TestMethod]
        public void PruebaUno()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }

        [TestMethod]
        public void PruebaDos()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }

        [TestMethod]
        public void PruebaTres()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }
    }
}