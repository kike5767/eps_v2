// IConexion.cs - stub
