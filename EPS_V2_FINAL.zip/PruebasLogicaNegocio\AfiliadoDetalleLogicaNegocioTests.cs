      using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PruebasLogicaNegocio
{
    [TestClass]
    public class AfiliadoDetalleLogicaNegocioTests
    {
        [TestMethod]
        public void ValidarLogicaNegocio_AfiliadoDetalle_1()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }

        [TestMethod]
        public void ValidarLogicaNegocio_AfiliadoDetalle_2()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }

        [TestMethod]
        public void ValidarLogicaNegocio_AfiliadoDetalle_3()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }
    }
}