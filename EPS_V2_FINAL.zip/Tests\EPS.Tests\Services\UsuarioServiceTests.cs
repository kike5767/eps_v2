using Xunit;

namespace EPS.Tests.Services {
    public class UsuarioServiceTests {
        [Fact]
        public void CrearUsuario_DebeGuardarCorrectamente() {
            // Arrange
            // Act
            // Assert
            Assert.True(true);
        }
    }
}
