    public void ValidarLogicaNegocio_Categoria()
{
    // Código de prueba 1
}

public void ValidarLogicaNegocio_Categoria_2()
{
    // Código de prueba 2
}

public void ValidarLogicaNegocio_Categoria_3()
{
    // Código de prueba 3
}