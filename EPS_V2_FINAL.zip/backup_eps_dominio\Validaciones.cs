namespace libreria_dominio.Helpers
{
    public static class Validaciones
    {
        public static bool EmailValido(string email)
        {
            return !string.IsNullOrEmpty(email) && email.Contains('@');
        }
    }
}
