﻿// EntidadesNucleo.cs - stub (optional)
