      public void ValidarLogicaNegocio_Departamento()
{
    // Código de prueba 1
}

public void ValidarLogicaNegocio_Departamento_2()
{
    // Código de prueba 2
}

public void ValidarLogicaNegocio_Departamento_3()
{
    // Código de prueba 3
}