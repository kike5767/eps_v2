     using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PruebasLogicaNegocio
{
    [TestClass]
    public class AfiliadoLogicaNegocioTests
    {
        [TestMethod]
        public void ValidarLogicaNegocio_Afiliado_1()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }

        [TestMethod]
        public void ValidarLogicaNegocio_Afiliado_2()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }

        [TestMethod]
        public void ValidarLogicaNegocio_Afiliado_3()
        {
            bool resultado = true;
            Assert.IsTrue(resultado);
        }
    }
}