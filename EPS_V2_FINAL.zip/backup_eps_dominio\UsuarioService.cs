using libreria_dominio.Entidades;

namespace libreria_dominio.Servicios
{
    public class UsuarioService
    {
        public void CrearUsuario(Usuario usuario)
        {
            // L�gica de negocio de ejemplo
        }
    }
}
