namespace libreria_dominio.Entidades
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
        public TipoUsuario Tipo { get; set; }
        public Estado Estado { get; set; }
    }
}
