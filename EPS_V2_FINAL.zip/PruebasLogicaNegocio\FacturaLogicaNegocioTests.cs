     public void ValidarLogicaNegocio_Factura()
{
    // Código de prueba 1
}

public void ValidarLogicaNegocio_Factura_2()
{
    // Código de prueba 2
}

public void ValidarLogicaNegocio_Factura_3()
{
    // Código de prueba 3
}