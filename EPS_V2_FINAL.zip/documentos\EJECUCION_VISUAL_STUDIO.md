# 🎬 EJECUCIÓN COMPLETA EN VISUAL STUDIO CON SQL SERVER
## Guía Visual Paso a Paso - Pantalla Completa

---

## 📋 PREPARACIÓN INICIAL

### 1. Abrir Visual Studio

```
┌─────────────────────────────────────────────────────────────┐
│  Visual Studio 2022                                         │
│  File  Edit  View  Project  Build  Debug  Test  Tools  Help  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  [Open a project or solution]                              │
│                                                             │
│  Recent:                                                    │
│  • EPS.sln                                                   │
│  • [Other projects...]                                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Acción:** File → Open → Project/Solution → Seleccionar `EPS.sln`

---

## 🗂️ PASO 1: ESTRUCTURA DEL PROYECTO EN SOLUTION EXPLORER

### Vista en Visual Studio:

```
┌─────────────────────────────────────────────────────────────┐
│  Solution Explorer                          Properties      │
├─────────────────────────────────────────────────────────────┤
│  📁 Solution 'EPS' (6 projects)                            │
│  │                                                          │
│  ├─ 📁 1. presentaciones                                    │
│  │  ├─ 📁 asp_presentacion                                 │
│  │  │  ├─ 📁 Pages                                          │
│  │  │  │  ├─ Afiliados.cshtml                              │
│  │  │  │  └─ Afiliados.cshtml.cs                           │
│  │  │  ├─ Program.cs                                        │
│  │  │  └─ asp_presentacion.csproj                          │
│  │  └─ 📁 lib_presentaciones                               │
│  │     ├─ Comunicaciones.cs                                │
│  │     └─ lib_presentaciones.csproj                        │
│  │                                                          │
│  ├─ 📁 2. servicios                                        │
│  │  ├─ 📁 asp_servicios                                    │
│  │  │  ├─ 📁 Controllers                                   │
│  │  │  │  ├─ TokenController.cs                            │
│  │  │  │  └─ AfiliadosController.cs                         │
│  │  │  ├─ 📁 Nucleo                                        │
│  │  │  │  └─ Configuracion.cs                             │
│  │  │  ├─ Program.cs                                        │
│  │  │  └─ asp_servicios.csproj                             │
│  │  └─ 📁 lib_repositorios                                 │
│  │     ├─ 📁 Implementaciones                              │
│  │     │  ├─ Conexion.cs                                   │
│  │     │  ├─ TokenAplicacion.cs                            │
│  │     │  └─ AfiliadosAplicacion.cs                        │
│  │     └─ lib_repositorios.csproj                          │
│  │                                                          │
│  ├─ 📁 3. nucleo                                           │
│  │  └─ 📁 lib_dominio                                       │
│  │     ├─ 📁 Entidades                                     │
│  │     ├─ 📁 Nucleo                                        │
│  │     └─ lib_dominio.csproj                               │
│  │                                                          │
│  └─ 📁 4. pruebas unitarias                                │
│     └─ 📁 Tests/EPS.Tests                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Estado:** ✅ Estructura visible y organizada

---

## 🗄️ PASO 2: CONFIGURAR SQL SERVER

### 2.1 Abrir SQL Server Management Studio (SSMS)

```
┌─────────────────────────────────────────────────────────────┐
│  Microsoft SQL Server Management Studio                    │
├─────────────────────────────────────────────────────────────┤
│  Connect to Server                                          │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Server type: Database Engine                        │   │
│  │ Server name: localhost\SQLEXPRESS                   │   │
│  │ Authentication: Windows Authentication              │   │
│  │                                                     │   │
│  │                    [Connect]                       │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Acción:** Conectar a `localhost\SQLEXPRESS`

### 2.2 Ejecutar Script SQL

```
┌─────────────────────────────────────────────────────────────┐
│  Object Explorer                    Query                    │
├─────────────────────────────────────────────────────────────┤
│  📁 localhost\SQLEXPRESS                                    │
│  ├─ 📁 Databases                                            │
│  │  └─ 📁 EPSDB  ← (Se creará aquí)                        │
│  └─ ...                                                     │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ File → Open → File → SCRIPCORREGIDOULTIMO...sql    │   │
│  │                                                     │   │
│  │ USE [master];                                       │   │
│  │ IF DB_ID('EPSDB') IS NULL                           │   │
│  │ BEGIN                                               │   │
│  │     CREATE DATABASE EPSDB;                          │   │
│  │ END;                                                │   │
│  │ ...                                                 │   │
│  │                                                     │   │
│  │ [Execute] (F5)                                      │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Messages:                                                  │
│  ✅ Commands completed successfully.                       │
│  ✅ Database 'EPSDB' created.                            │
│  ✅ Tables created successfully.                           │
└─────────────────────────────────────────────────────────────┘
```

**Resultado:** ✅ Base de datos `EPSDB` creada con todas las tablas

---

## 🔨 PASO 3: COMPILAR EN VISUAL STUDIO

### 3.1 Build Solution

**Vista en Visual Studio:**

```
┌─────────────────────────────────────────────────────────────┐
│  Visual Studio - EPS.sln                                    │
├─────────────────────────────────────────────────────────────┤
│  Build  Debug  Test  Analyze  Tools  Extensions  Window    │
│                                                             │
│  [Build] → [Build Solution] (Ctrl+Shift+B)                 │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Output                                              │   │
│  ├─────────────────────────────────────────────────────┤   │
│  │ Build started...                                    │   │
│  │ 1>------ Build started: Project: lib_dominio...     │   │
│  │ 1>lib_dominio -> C:\EPS_V2_FINAL\lib_dominio\...   │   │
│  │ 1>------ Build started: Project: lib_repositorios  │   │
│  │ 1>lib_repositorios -> C:\EPS_V2_FINAL\...          │   │
│  │ 1>------ Build started: Project: lib_presentaciones │   │
│  │ 1>lib_presentaciones -> C:\EPS_V2_FINAL\...        │   │
│  │ 1>------ Build started: Project: asp_servicios...   │   │
│  │ 1>asp_servicios -> C:\EPS_V2_FINAL\asp_servicios\...│   │
│  │ 1>------ Build started: Project: asp_presentacion  │   │
│  │ 1>asp_presentacion -> C:\EPS_V2_FINAL\...          │   │
│  │ 1>------ Build started: Project: EPS.Tests...       │   │
│  │ 1>EPS.Tests -> C:\EPS_V2_FINAL\Tests\...           │   │
│  │ ========== Build: 6 succeeded, 0 failed ========== │   │
│  │ ✅ Build succeeded                                   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Error List: (Empty - No errors)                           │
│  Warning List: (Minimal warnings)                          │
└─────────────────────────────────────────────────────────────┘
```

**Resultado:** ✅ Build succeeded - 6 proyectos compilados

---

## 🧪 PASO 4: EJECUTAR PRUEBAS UNITARIAS

### 4.1 Test Explorer

```
┌─────────────────────────────────────────────────────────────┐
│  Test Explorer                                              │
├─────────────────────────────────────────────────────────────┤
│  🔍 Search tests...                                         │
│                                                             │
│  📁 EPS.Tests                                               │
│  ├─ ✅ EntityValidationTests                                │
│  │  ├─ ✅ TestAfiliadoValidation                           │
│  │  ├─ ✅ TestUsuarioValidation                            │
│  │  └─ ✅ TestContratoValidation                           │
│  └─ ✅ UsuarioServiceTests                                  │
│     └─ ✅ TestUsuarioService                               │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ [Run All] (Ctrl+R, A)                               │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Test Results:                                              │
│  ✅ Passed: 5                                               │
│  ❌ Failed: 0                                               │
│  ⏭️  Skipped: 0                                             │
│  ⏱️  Duration: 1.2s                                        │
└─────────────────────────────────────────────────────────────┘
```

**Acción:** Test → Run All Tests (Ctrl+R, A)

**Resultado:** ✅ Todas las pruebas pasaron

---

## 🚀 PASO 5: EJECUTAR API (asp_servicios)

### 5.1 Configurar como Proyecto de Inicio

```
┌─────────────────────────────────────────────────────────────┐
│  Solution Explorer                                          │
├─────────────────────────────────────────────────────────────┤
│  📁 asp_servicios                                           │
│  └─ 📄 asp_servicios.csproj                                 │
│                                                             │
│  [Right Click] → Set as Startup Project                     │
│                                                             │
│  [Debug] → [Start Debugging] (F5)                           │
└─────────────────────────────────────────────────────────────┘
```

### 5.2 Vista de Ejecución del API

```
┌─────────────────────────────────────────────────────────────┐
│  Visual Studio - asp_servicios                              │
├─────────────────────────────────────────────────────────────┤
│  Output                                                      │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ info: Microsoft.Hosting.Lifetime[14]                │   │
│  │       Now listening on: https://localhost:5047       │   │
│  │ info: Microsoft.Hosting.Lifetime[14]                │   │
│  │       Now listening on: http://localhost:5047       │   │
│  │ info: Microsoft.Hosting.Lifetime[0]                 │   │
│  │       Application started. Press Ctrl+C to shut down.│   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Browser (se abre automáticamente):                         │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ https://localhost:5047                               │   │
│  │                                                       │   │
│  │ {"message":"API EPS V2 Running"}                     │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Estado:** ✅ API ejecutándose en puerto 5047

---

## 🎨 PASO 6: EJECUTAR UI (asp_presentacion)

### 6.1 Cambiar Proyecto de Inicio

```
┌─────────────────────────────────────────────────────────────┐
│  Solution Explorer                                          │
├─────────────────────────────────────────────────────────────┤
│  📁 asp_presentacion                                        │
│  └─ 📄 asp_presentacion.csproj                              │
│                                                             │
│  [Right Click] → Set as Startup Project                     │
│                                                             │
│  [Debug] → [Start Debugging] (F5)                           │
└─────────────────────────────────────────────────────────────┘
```

### 6.2 Vista de Ejecución de la UI

```
┌─────────────────────────────────────────────────────────────┐
│  Visual Studio - asp_presentacion                           │
├─────────────────────────────────────────────────────────────┤
│  Output                                                      │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ info: Microsoft.Hosting.Lifetime[14]                │   │
│  │       Now listening on: https://localhost:5000       │   │
│  │ info: Microsoft.Hosting.Lifetime[14]                │   │
│  │       Now listening on: http://localhost:5000       │   │
│  │ info: Microsoft.Hosting.Lifetime[0]                 │   │
│  │       Application started. Press Ctrl+C to shut down.│   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Browser (se abre automáticamente):                         │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 🏥 EPS - Sistema de Gestión                          │   │
│  │ ┌─────────────────────────────────────────────────┐ │   │
│  │ │ [Inicio] [Afiliados]                           │ │   │
│  │ └─────────────────────────────────────────────────┘ │   │
│  │                                                     │   │
│  │  📋 Gestión de Afiliados - EPS                     │   │
│  │                                                     │   │
│  │  [+ Nuevo Afiliado]                                 │   │
│  │                                                     │   │
│  │  ┌───────────────────────────────────────────────┐ │   │
│  │  │ ID │ Nombre    │ Documento │ Email  │ Acciones│ │   │
│  │  ├────┼───────────┼───────────┼────────┼─────────┤ │   │
│  │  │ 1  │ Juan P.   │ 12345678  │ juan@..│ [Editar]│ │   │
│  │  │ 2  │ María G.  │ 87654321  │ maria@.│ [Editar]│ │   │
│  │  └───────────────────────────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Estado:** ✅ UI ejecutándose en puerto 5000 con tema morado

---

## 🔍 PASO 7: VERIFICAR CONEXIÓN A SQL SERVER

### 7.1 Server Explorer en Visual Studio

```
┌─────────────────────────────────────────────────────────────┐
│  Server Explorer                                            │
├─────────────────────────────────────────────────────────────┤
│  📁 Data Connections                                        │
│  └─ 📁 (localdb)\MSSQLLocalDB                               │
│     └─ 📁 EPSDB                                             │
│        ├─ 📁 Tables                                         │
│        │  ├─ 📄 Afiliado                                    │
│        │  ├─ 📄 Usuario                                      │
│        │  ├─ 📄 Contrato                                    │
│        │  ├─ 📄 Cita                                         │
│        │  └─ ... (todas las tablas)                         │
│        └─ 📁 Views                                          │
│                                                             │
│  [Right Click on EPSDB] → New Query                        │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ SELECT * FROM Afiliado;                             │   │
│  │ [Execute]                                           │   │
│  │                                                     │   │
│  │ Results:                                            │   │
│  │ Id │ Nombre    │ Documento │ Email      │ ...      │   │
│  │ 1  │ Juan P.   │ 12345678  │ juan@...   │ ...      │   │
│  │ 2  │ María G.  │ 87654321  │ maria@...  │ ...      │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Estado:** ✅ Conexión a SQL Server verificada

---

## 🧪 PASO 8: PROBAR CRUD COMPLETO

### 8.1 Crear Nuevo Afiliado

**Vista en el Navegador:**

```
┌─────────────────────────────────────────────────────────────┐
│  🏥 EPS - Sistema de Gestión                                │
│  [Inicio] [Afiliados]                                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  📋 Nuevo Afiliado                                          │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Nombre:        [________________]                    │   │
│  │ Documento:     [________________]                    │   │
│  │ Email:         [________________]                    │   │
│  │ Fecha Nac.:    [____/____/____]                     │   │
│  │ Teléfono:      [________________]                    │   │
│  │ Municipio ID:  [____]                                │   │
│  │ Dirección:     [________________]                    │   │
│  │                                                     │   │
│  │              [Guardar]  [Cancelar]                 │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Acción:** Llenar formulario → [Guardar]

**Resultado en Visual Studio Output:**
```
info: Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker[2]
      Executed action asp_servicios.Controllers.AfiliadosController.Guardar
      in 45.2ms
info: Microsoft.EntityFrameworkCore.Database.Command[20101]
      Executed DbCommand (25ms) [Parameters=[...], CommandType='Text',
      CommandTimeout='30']
      INSERT INTO [Afiliado] ([Nombre], [Documento], ...) VALUES (...)
```

### 8.2 Listar Afiliados

**Vista en el Navegador:**

```
┌─────────────────────────────────────────────────────────────┐
│  ✅ Afiliado guardado correctamente                         │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ ID │ Nombre      │ Documento │ Email      │ Acciones│   │
│  ├────┼─────────────┼───────────┼────────────┼─────────┤   │
│  │ 1  │ Juan P.     │ 12345678  │ juan@...   │ [Editar]│   │
│  │ 2  │ María G.    │ 87654321  │ maria@...  │ [Editar]│   │
│  │ 3  │ Nuevo A.    │ 11223344  │ nuevo@...  │ [Editar]│   │ ← Nuevo
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### 8.3 Editar Afiliado

**Vista en el Navegador:**

```
┌─────────────────────────────────────────────────────────────┐
│  📋 Editar Afiliado                                         │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ ID: 3                                               │   │
│  │ Nombre:        [Nuevo Afiliado Modificado]          │   │
│  │ Documento:     [11223344]                           │   │
│  │ Email:         [nuevo@email.com]                      │   │
│  │ ...                                                   │   │
│  │              [Guardar]  [Cancelar]                 │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Resultado:** ✅ Afiliado modificado exitosamente

### 8.4 Borrar Afiliado

**Vista en el Navegador:**

```
┌─────────────────────────────────────────────────────────────┐
│  ⚠️ ¿Está seguro de borrar este afiliado?                  │
│                                                             │
│  [Sí, borrar]  [Cancelar]                                  │
└─────────────────────────────────────────────────────────────┘
```

**Resultado en Visual Studio Output:**
```
info: Microsoft.EntityFrameworkCore.Database.Command[20101]
      Executed DbCommand (15ms) [Parameters=[...], CommandType='Text',
      CommandTimeout='30']
      DELETE FROM [Afiliado] WHERE [Id] = 3
```

---

## 📊 PASO 9: VERIFICAR EN SQL SERVER

### 9.1 Ver Datos en SSMS

```
┌─────────────────────────────────────────────────────────────┐
│  SQL Server Management Studio                               │
├─────────────────────────────────────────────────────────────┤
│  Object Explorer                    Query                    │
├─────────────────────────────────────────────────────────────┤
│  📁 EPSDB                                                    │
│  └─ 📁 Tables                                                │
│     └─ 📄 dbo.Afiliado                                       │
│        [Right Click] → Select Top 1000 Rows                 │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Results:                                            │   │
│  │ ┌────┬─────────────┬───────────┬─────────────┬─────┐│   │
│  │ │ Id │ Nombre     │ Documento │ Email       │ ... ││   │
│  │ ├────┼─────────────┼───────────┼─────────────┼─────┤│   │
│  │ │ 1  │ Juan P.     │ 12345678  │ juan@...    │ ... ││   │
│  │ │ 2  │ María G.    │ 87654321  │ maria@...   │ ... ││   │
│  │ │ 3  │ Nuevo A.    │ 11223344  │ nuevo@...   │ ... ││   │
│  │ └────┴─────────────┴───────────┴─────────────┴─────┘│   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

**Estado:** ✅ Datos visibles en SQL Server

---

## 🎯 RESUMEN DE EJECUCIÓN COMPLETA

### Orden de Ejecución:

1. ✅ **Abrir Visual Studio** → Abrir `EPS.sln`
2. ✅ **Configurar SQL Server** → Ejecutar script SQL
3. ✅ **Compilar** → Build Solution (Ctrl+Shift+B)
4. ✅ **Ejecutar Pruebas** → Test Explorer → Run All
5. ✅ **Ejecutar API** → Set asp_servicios as Startup → F5
6. ✅ **Ejecutar UI** → Set asp_presentacion as Startup → F5
7. ✅ **Probar CRUD** → Crear, Listar, Editar, Borrar
8. ✅ **Verificar SQL Server** → Ver datos en SSMS

### Resultado Final:

```
✅ Proyecto compilado exitosamente
✅ Pruebas unitarias pasadas
✅ API ejecutándose en puerto 5047
✅ UI ejecutándose en puerto 5000
✅ CRUD funcionando correctamente
✅ Datos guardados en SQL Server
✅ Tema morado visible en UI
✅ Comentarios línea por línea en código
```

---

## 📝 NOTAS IMPORTANTES

1. **Ejecutar API y UI por separado:**
   - Primero ejecutar API (asp_servicios)
   - Luego ejecutar UI (asp_presentacion)
   - O usar múltiples proyectos de inicio

2. **Configurar Multiple Startup Projects:**
   - Right Click Solution → Properties
   - Multiple startup projects
   - Seleccionar: asp_servicios y asp_presentacion
   - Action: Start

3. **Ver Logs en Visual Studio:**
   - Output window muestra toda la ejecución
   - Debug window muestra llamadas a la API
   - Test Explorer muestra resultados de pruebas

---

**¡Ejecución completa visualizada!** 🎉

