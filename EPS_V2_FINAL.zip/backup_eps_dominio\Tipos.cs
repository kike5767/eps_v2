namespace libreria_dominio
{
    public enum Estado { Activo, Inactivo }
    public enum TipoUsuario { Administrador, Normal }
}
