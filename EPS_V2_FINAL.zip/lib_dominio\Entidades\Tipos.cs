﻿// Tipos.cs - stub
