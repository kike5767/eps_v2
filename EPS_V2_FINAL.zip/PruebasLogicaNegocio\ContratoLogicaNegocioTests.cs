       public void ValidarLogicaNegocio_Contrato()
{
    // Código de prueba 1
}

public void ValidarLogicaNegocio_Contrato_2()
{
    // Código de prueba 2
}

public void ValidarLogicaNegocio_Contrato_3()
{
    // Código de prueba 3
}