      public void ValidarLogicaNegocio_HistoriaMedica()
{
    // Código de prueba 1
}

public void ValidarLogicaNegocio_HistoriaMedica_2()
{
    // Código de prueba 2
}

public void ValidarLogicaNegocio_HistoriaMedica_3()
{
    // Código de prueba 3
}
