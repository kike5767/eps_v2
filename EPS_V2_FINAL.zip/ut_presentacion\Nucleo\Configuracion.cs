﻿// Configuracion.cs - stub
