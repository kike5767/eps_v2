     public void ValidarLogicaNegocio_Cita()
{
    // Código de prueba 1
}

public void ValidarLogicaNegocio_Cita_2()
{
    // Código de prueba 2
}

public void ValidarLogicaNegocio_Cita_3()
{
    // Código de prueba 3
}